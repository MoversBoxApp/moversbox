
function changeCSS(cssFile, cssLinkIndex)
{
document.getElementById('style').href=cssFile;

}
function setLogo(logoFile, cssLinkIndex)
{

document.getElementById('logocustom').src=logoFile;

}
