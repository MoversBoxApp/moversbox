/*
----------------------------------------------
    : Custom - CRM Projects js :
----------------------------------------------
*/
"use strict";
$(document).ready(function() {   
    /* -- Piety - Data Attributes Chart -- */
    $(".piety-data-attributes span").peity("donut");    
});