/*
--------------------------------------
    : Custom - eCommerce Page js :
--------------------------------------
*/
"use strict";
$(document).ready(function() {
    $('.summernote').summernote({
        height: 200,
        minHeight: null,
        maxHeight: null,
        focus: true 
    });
});